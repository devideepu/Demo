interface common
{
	void accept();
	void display();
}
