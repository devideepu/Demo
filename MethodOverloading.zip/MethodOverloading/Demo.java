class Demo
{
	public static void main(String args[])
	{
		Person_name pn=new Person_name();
		System.out.println("First method:"+pn.get_fullname());	//Same method overloaded three types
		System.out.println("Second method:"+pn.get_fullname(2));
		System.out.println("Third method:"+pn.get_fullname("Thirupathi"));
	}
}
