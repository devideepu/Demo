class Person_name
{
	public String get_fullname()	//Method with no arguments
	{
		String fn="Devi";
		String ln="Mulakala";
		return fn+" "+ln;
	}
	public String get_fullname(int space)	//Method with integer as argument
	{
		String fn="Devi";
		String ln="Mulakala";
		String spaces=" ";
		for(int s=1;s<=space;s++)
			spaces+=" "; 
		return fn+spaces+ln;
	}
	public String get_fullname(String fn)	//Method with String as argument
	{
		String mn="Devi";
		String ln="Mulakala";
		return fn+" "+mn+" "+ln;
	}
}
