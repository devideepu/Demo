class Printer
{
	synchronized void print(int start,int end,int delay)	//Synchronizing three threads
	{
		System.out.println("[");
		for(int i=start;i<=end;i++)
		{
			System.out.println(""+i);
			try
			{
				Thread.sleep(delay);
			}
			catch(InterruptedException ex)
			{
				System.out.println("Thread Interrupted");
			}
		}
		System.out.println("]");
	}
}
