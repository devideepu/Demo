class User extends Thread
{
	Printer p;
	int start,end,delay;
	User(Printer p,int start,int end,int delay)	//Constructor which intializes values of 3 threads
	{
		this.p=p;
		this.start=start;
		this.end=end;
		this.delay=delay;
	}
	public void run()
	{
		synchronized(p)
		{
			p.print(start,end,delay);
		}
	}
}
