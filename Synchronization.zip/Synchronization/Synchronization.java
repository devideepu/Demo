class Synchronization
{
	public static void main(String args[])
	{
		Printer p=new Printer();
		User u1=new User(p,1,10,1000);	//Creating three threads 
		User u2=new User(p,26,30,2000);
		User u3=new User(p,41,45,1500);
		u1.start();
		u2.start();
		u3.start();
	}
}
