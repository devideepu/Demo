class Consumer extends Thread
{
	Que q;
	boolean r=true;
	Consumer(Que q)
	{
		this.q=q;
	}
	public void run()
	{
		while(r)
		{
			q.get();
			try
			{
				Thread.sleep(3000);
			}
			catch(InterruptedException e)
			{
			
			}
		}
	}
	public void work()
	{
		r=false;
	}
}
