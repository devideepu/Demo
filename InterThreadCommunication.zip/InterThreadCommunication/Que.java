class Que
{
	int element;
	boolean status=false;
	synchronized public void put(int n)
	{
		if(status)
		{
			try
			{
				wait();
			}
			catch(InterruptedException e)
			{
				System.out.println(element);
			}
		}
		this.element=n;
		System.out.println("produced:"+element);
		status=true;
		notify();		//Notifying consumer that Producer has produced
	}
	synchronized public int get()
	{
		 if(!status)
		 {
		 	try
		 	{
		 		wait();
		 	}
		 	catch(InterruptedException e)
		 	{
		 		System.out.println(element);
		 	}
		 }
		 System.out.println("Consumed:"+this.element);
		 status=false;
		 notify();	//Notifying Producer that consumer has consumed
		 return element;
	}
}
