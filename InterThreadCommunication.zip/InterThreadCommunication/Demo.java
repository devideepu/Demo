import java.util.*;
class Demo
{
	public static void main(String args[])
	{
		Que obj=new Que();	//Que to maintain inter thread communication
		Scanner t=new Scanner(System.in);
		Producer p=new Producer(obj);
		Consumer c=new Consumer(obj);
		System.out.println("Press Enter to terminate");
		p.start();
		c.start();
		String s=t.nextLine();
		p.work();
		c.work();
	}
}
