import java.util.*;
class Producer extends Thread
{
	Random i=new Random();
	Que q;
	boolean r=true;
	Producer(Que q)
	{
		this.q=q;
	}
	public void run()
	{
		
		while(r)
		{
			q.put(i.nextInt(10));
			try
			{
				Thread.sleep(3000);
			}
			catch(InterruptedException e)
			{
			
			}
		}
		
	}
	public void work()
	{
		r=false;
	}
}
